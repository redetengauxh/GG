
Запуск: python btc_ress.py -arg

options:
  -h, --help  show this help message and exit
  -b          Поиск забытых биткоин кошельков
  -a          Парсинг по сидке биткоин адреса в глубь кошелька
  -e          Поиск эфировских кошельков и форков
  -w          Парсинг по сидке эфира и форков в глубь кошелька

Библиотеки: pip install -r requirements.txt

Виртуальная среда(по желанию):

pip install virtualenv
python -m venv venv .venv
venv\Scripts\activate

pip install -r requirements.txt