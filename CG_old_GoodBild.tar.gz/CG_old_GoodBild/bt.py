import time
from bitcoinlib.encoding import *
from bitcoinlib.wallets import *
from bitcoinlib.keys import *
from bitcoinlib.mnemonic import Mnemonic
from colored import fg, bg, attr
import bip32utils
import ctypes
from concurrent.futures import ThreadPoolExecutor
from queue import Queue
import requests


timesl = 1
class Settings:
    save_empty = "y"
    total_count = 0
    wet_count = 0
    dry_count = 0

def sendBotMsg(msg, token_bot, chat_id):
    if token_bot:
        try:
            requests.post(f"https://api.telegram.org/bot{token_bot}/sendmessage?chat_id={chat_id}&text={msg}")
        except:
            print("netu tokena")

def getseeds(wordlists):
    with open(wordlists, 'r', encoding='utf-8') as file:
        seed_phrases = file.read().splitlines()
        return seed_phrases

def listToString(s):
    str1 = "|"
    return (str1.join(s))

def getBalance(address):
    response = requests.get(f'https://blockchain.info/multiaddr?active={address}&n=1')
    return response.json()

def process_seed(seed_phrase, num_children, result_queue ,token_bot, chat_id):
    timesl = 1
    time.sleep(timesl)
    
    try:
        mnemonic = Mnemonic('english')
        seed = mnemonic.to_seed(seed_phrase)
        root_key = bip32utils.BIP32Key.fromEntropy(seed)
        root_address = root_key.Address()
        root_public_hex = root_key.PublicKey().hex()
        root_private_wif = root_key.WalletImportFormat()
        print(f'Seed Phrase: {seed_phrase}')
        print('Root key:')
        print(f'\tAddress: {root_address}')
        print(f'\tPublic : {root_public_hex}')
        print(f'\tPrivate: {root_private_wif}\n')
        balances = getBalance(root_address)
        colortmp = 1
        for item in balances["addresses"]:
            addy = item["address"]
            balance = item["final_balance"]
            received = item["total_received"]
           
            
            if balance > 0:
                msg = 'Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}'.format(balance, received, addy, seed_phrase)
                sendBotMsg(msg, token_bot, chat_id)
                if colortmp == 1:
                    colortmp = 0
                    print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#008700"), balance, received, addy, seed_phrase, attr( "reset")))
                   
                else:
                    colortmp = 1
                    print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#008700"), balance, received, addy, seed_phrase, attr( "reset")))
            else:
                if received > 0:
                    msg = 'Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}'.format(balance, received, addy, seed_phrase)
                    sendBotMsg(msg, token_bot, chat_id)
                    if colortmp == 1:
                        colortmp = 0
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#005FFF"), balance, received, addy, seed_phrase, attr( "reset")))
                    else:
                        colortmp = 1
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#005FFF"), balance, received, addy, seed_phrase, attr( "reset")))
                else:
                    if colortmp == 1:
                        colortmp = 0
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#FFFFFF"), balance, received, addy, seed_phrase, attr( "reset")))
                    else:
                        colortmp = 1
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#000000")+bg("#808080"), balance, received, addy, seed_phrase, attr( "reset")))
            Settings.total_count += 1
            #if Settings.save_empty == "y":
          #       ctypes.windll.kernel32.SetConsoleTitleW(f"Empty: {Settings.dry_count} - Hits: {Settings.wet_count} - Total checks: {Settings.total_count}")
          #  else:
          #       ctypes.windll.kernel32.SetConsoleTitleW(f"Hits: {Settings.wet_count} - Total checks: {Settings.total_count}")
            if balance > 0:
                with open('results/parsewet.txt', 'w') as w:
                    w.write(f'Address: {addy} | Balance: {balance} |\n')
                Settings.wet_count += 1
            else:
                  if Settings.save_empty == "n":
                    pass
                  else:
                    with open('results/parsedry.txt', 'w') as w:
                        w.write(f'Address: {addy} | Balance: {balance} | Mnemonic phrase: {seed_phrase}\n')
                    Settings.dry_count += 1
        time.sleep(timesl)
            

            
        for i in range(num_children):
            child_key = root_key.ChildKey(0).ChildKey(i)
            child_address = child_key.Address()
            child_public_hex = child_key.PublicKey().hex()
            child_private_wif = child_key.WalletImportFormat()
            print(f'Child key m/0/{i}:')
            print(f'\tAddress: {child_address}')
            print(f'\tPublic : {child_public_hex}')
            print(f'\tPrivate: {child_private_wif}\n')
            balances = getBalance(child_address)
            colortmp = 1
            for item in balances["addresses"]:
                addy = item["address"]
                balance = item["final_balance"]
                received = item["total_received"]
                
            
                if balance > 0:
                    msg = 'Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}'.format(balance, received, addy, seed_phrase)
                    sendBotMsg(msg, token_bot, chat_id)
                    if colortmp == 1:
                        colortmp = 0
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#008700"), balance, received, addy, seed_phrase, attr( "reset")))
                   
                    else:
                        colortmp = 1
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#008700"), balance, received, addy, seed_phrase, attr( "reset")))
                else:
                    if received > 0:
                        msg = 'Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}'.format(balance, received, addy, seed_phrase)
                        sendBotMsg(msg, token_bot, chat_id)
                        if colortmp == 1:
                            colortmp = 0
                            print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#005FFF"), balance, received, addy, seed_phrase, attr( "reset")))
                        else:
                            colortmp = 1
                            print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#005FFF"), balance, received, addy, seed_phrase, attr( "reset")))
                    else:
                        if colortmp == 1:
                            colortmp = 0
                            print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#FFFFFF"), balance, received, addy, seed_phrase, attr( "reset")))
                        else:
                            colortmp = 1
                            print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#000000")+bg("#808080"), balance, received, addy, seed_phrase, attr( "reset")))
                Settings.total_count += 1
                #if Settings.save_empty == "y":
                #     ctypes.windll.kernel32.SetConsoleTitleW(f"Empty: {Settings.dry_count} - Hits: {Settings.wet_count} - Total checks: {Settings.total_count}")
               # else:
                #    ctypes.windll.kernel32.SetConsoleTitleW(f"Hits: {Settings.wet_count} - Total checks: {Settings.total_count}")
                if balance > 0:
                    with open('results/parsewet.txt', 'a') as w:
                        w.write(f'Address: {addy} | Balance: {balance} |\n')
                        Settings.wet_count += 1
                else:
                    if Settings.save_empty == "n":
                        pass
                    else:
                         with open('results/parsedry.txt', 'a') as w:
                            w.write(f'Address: {addy} | Balance: {balance} | Mnemonic phrase: {seed_phrase}\n')
                            Settings.dry_count += 1
            time.sleep(timesl)

    

        result_queue.put((seed_phrase, balance, received, addy, None))
    except Exception as e:
        result_queue.put((seed_phrase, None, None, None, str(e)))
        

def recoveraddr(seed_phrases, num_children, threads, token_bot, chat_id):
    result_queue = Queue()
    msg = f' Получаю root_key и начинаю парсинг child_key '
    sendBotMsg(msg,token_bot, chat_id)
    with ThreadPoolExecutor(max_workers=threads) as executor:
        for seed_phrase in seed_phrases:
            executor.submit(process_seed, seed_phrase, num_children, result_queue, token_bot, chat_id)
    return result_queue