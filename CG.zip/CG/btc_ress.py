import grequests
import bt
import eth_parse
import eth_gener
import pprint
import mnemonic
import time
import bip32utils
from bitcoinlib.encoding import *
from bitcoinlib.wallets import *
from bitcoinlib.keys import *
from bitcoinlib.mnemonic import Mnemonic
import bip32utils
import random
import os
from colored import fg, bg, attr
from decimal import Decimal
from multiprocessing.pool import ThreadPool as Pool
from Bip39Gen import Bip39Gen
from time import sleep
import ctypes
import argparse
import requests


### Папки ###
timesl = 1
path = os.path.abspath(os.curdir)
print("\nТекущая папка: " + path)
time.sleep(1)
fileList = os.listdir(path)

class Settings:
    save_empty = "y"
    total_count = 0
    wet_count = 0
    dry_count = 0

#Создание директорий
def makeDir():
    path = 'results_btc'
    if not os.path.exists(path):
        os.makedirs(path)

def makeDir_parse():
    path = 'results_parse_btc'
    if not os.path.exists(path):
        os.makedirs(path)

def makeDir_eth():
    path = 'result_eth'
    if not os.path.exists(path):
        os.makedirs(path)

def makeDir_eth_parse():
    path = 'result_eth_parse'
    if not os.path.exists(path):
        os.makedirs(path)

def getThreadsCount():
    try:
        threads = int(input("Введите количество потоков: "))
        if threads > 666:
            print("Можно использовать только 666 потоков максимум.")
            return getThreadsCount()
        return threads
    except ValueError:
        print("Введите целое число.")
        return getThreadsCount()

def getBalance(address):
    response = requests.get(f'https://blockchain.info/multiaddr?active={address}&n=1')
    return response.json()

#Подбор файлов

def getMnemonicWordsFile(filename):
    if filename in fileList:
        print("\nФайл найден товарищ и запущен в работу!\n ")
        with open(filename, 'r', encoding='utf-8') as file:
            wordlist = [line.strip() for line in file]
        return wordlist
    else:
        time.sleep(0.5)
        print("\nФайл не найден в данный папке! Введи имя файла заново!")
        filename = input("\nВводи название файла вместе с расширением пример: 'info.txt'\n Для продолжения нажми 'Enter'")
        userInput()

def getMnemonicWordsFiles(filename):
    if filename in fileList:
        print("\nФайл найден товарищ и запущен в работу!\n ")
        wordlists =  filename
        return wordlists
    else:
        time.sleep(0.5)
        print("\nФайл не найден в данный папке! Введи имя файла заново!")
        filename = input("\nВводи название файла вместе с расширением пример: 'info.txt'\n Для продолжения нажми 'Enter'")
        btc_seed_check_parse()

def getMnemonicWordsFilesEth_parse(filename):
    if filename in fileList:
        print("\nФайл найден товарищ и запущен в работу!\n ")
        wordlists =  filename
        return wordlists
    else:
        time.sleep(0.5)
        print("\nФайл не найден в данный папке! Введи имя файла заново!")
        filename = input("\nВводи название файла вместе с расширением пример: 'info.txt'\n Для продолжения нажми 'Enter'")
        eth_parses()

def getMnemonicWordsFilesEth(filename):
    if filename in fileList:
        print("\nФайл найден товарищ и запущен в работу!\n ")
        with open(filename, 'r', encoding='utf-8') as file:
            wordlist = [line.strip() for line in file]
        return wordlist
    else:
        time.sleep(0.5)
        print("\nФайл не найден в данный папке! Введи имя файла заново!")
        filename = input("\nВводи название файла вместе с расширением пример: 'info.txt'\n Для продолжения нажми 'Enter'")
        eth_seeds()

#Основа

def generateSeedbtc(wordlist):
    seed = ""
    for i in range(12):
        seed += random.choice(wordlist) if i == 0 else ' ' + random.choice(wordlist)
    return seed

def bip39(mnemonic_words):
    mobj = mnemonic.Mnemonic("english")
    seed = mobj.to_seed(mnemonic_words)

    bip32_root_key_obj = bip32utils.BIP32Key.fromEntropy(seed)
    bip32_child_key_obj = bip32_root_key_obj.ChildKey(
        44 + bip32utils.BIP32_HARDEN
    ).ChildKey(
        0 + bip32utils.BIP32_HARDEN
    ).ChildKey(
        0 + bip32utils.BIP32_HARDEN
    ).ChildKey(0).ChildKey(0)

    return bip32_child_key_obj.Address()

def generateBd(wordlist):
    adrBd = {}
    for i in range(100):
        mnemonic_words = generateSeedbtc(wordlist)
        addy = bip39(mnemonic_words)
        adrBd.update({addy: mnemonic_words})
    return adrBd

def listToString(s):
    str1 = "|"
    return (str1.join(s))

def sendBotMsg(msg, token_bot, chat_id):
    if token_bot:
        try:
            requests.post(f"https://api.telegram.org/bot{token_bot}/sendmessage?chat_id={chat_id}&text={msg}")
        except:
            print("netu tokena")
    
def check(wordlist, token_bot, chat_id):
    while True:
        bdaddr = generateBd(wordlist)
        addys = listToString(list(bdaddr))
        balances = getBalance(addys)
        colortmp = 1
        for item in balances["addresses"]:
            addy = item["address"]
            balance = item["final_balance"]
            received = item["total_received"]
            mnemonic_words = bdaddr[addy]
            
            if balance > 0:
                msg = 'Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}'.format(balance, received, addy, mnemonic_words)
                sendBotMsg(msg, token_bot, chat_id)
                if colortmp == 1:
                    colortmp = 0
                    print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#008700"), balance, received, addy, mnemonic_words, attr( "reset")))
                else:
                    colortmp = 1
                    print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(bg("#008700"), balance, received, addy, mnemonic_words, attr("reset")))
            else:
                if received > 0:
                    msg = 'Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}'.format(balance, received, addy, mnemonic_words)
                    sendBotMsg(msg, token_bot, chat_id)
                    if colortmp == 1:
                        colortmp = 0
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#005FFF"), balance, received, addy, mnemonic_words, attr("reset")))
                    else:
                        colortmp = 1
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(bg("#005FFF"), balance, received, addy, mnemonic_words, attr("reset")))
                else:
                    if colortmp == 1:
                        colortmp = 0
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#FFFFFF"), balance, received, addy, mnemonic_words, attr("reset")))
                    else:
                        colortmp = 1
                        print('{}Balance: {} | Received: {} | Address: {} | Mnemonic phrase: {}{}'.format(fg("#000000")+bg("#808080"), balance, received, addy, mnemonic_words, attr("reset")))
            Settings.total_count += 1
           # if Settings.save_empty == "y":
          #      ctypes.windll.kernel32.SetConsoleTitleW(f"Empty: {Settings.dry_count} - Hits: {Settings.wet_count} - Total checks: {Settings.total_count}")
          #  else:
          #      ctypes.windll.kernel32.SetConsoleTitleW(f"Hits: {Settings.wet_count} - Total checks: {Settings.total_count}")
            if balance > 0:
                with open('results/wet.txt', 'a') as w:
                    w.write(f'Address: {addy} | Balance: {balance} | Mnemonic phrase: {mnemonic_words}\n')
                Settings.wet_count += 1
            else:
                if Settings.save_empty == "n":
                    pass
                else:
                    with open('results/dry.txt', 'a') as w:
                        w.write(f'Address: {addy} | Balance: {balance} | Mnemonic phrase: {mnemonic_words}\n')
                    Settings.dry_count += 1
        time.sleep(timesl)

def starts(wordlists, token_bot, chat_id, threads, num_children):
    Settings.save_empty = "n"
    msg = 'Скрипт парсинг вглубь сид-фраз биткоин кошельков запущен!'
    sendBotMsg(msg, token_bot, chat_id)
    seed_phrases = bt.getseeds(wordlists)
    print(f"Начинаю просчитывать сид фразы из текстовика ожидай...")
    
    result_queue = bt.recoveraddr(seed_phrases, num_children, threads, token_bot, chat_id)
    processed_seeds = 0  
    
    for _ in range(len(seed_phrases)):
        seed_phrase, balance, received, addy, error = result_queue.get()
        if error:
            print(f"Error for seed phrase '{seed_phrase}': {error}")
            continue
        else:
            processed_seeds += 1

    if processed_seeds == len(seed_phrases):
        print("Скрипт закончил работу")
        msg = 'Скрипт парсинг вглубь сид-фраз биткоин кошельков закончил работу!'
        sendBotMsg(msg, token_bot, chat_id)
    time.sleep(timesl)
    
def start_gen_eth(wordlist, token_bot, chat_id, threads):
    Settings.save_empty = "n"
    msg = 'Скрипт поиска забытых биткоин кошельков запущен!'
    sendBotMsg(msg, token_bot, chat_id)
    while True:
        pool = Pool(threads)
        for _ in range(threads):
            pool.apply_async(eth_gener.ma_check(wordlist,token_bot, chat_id))
        pool.close()
        pool.join()
        time.sleep(timesl)  
    
def start_eth_parse(wordlists, token_bot, chat_id, threads, num_children):
    Settings.save_empty = "n"
    msg = 'Скрипт парсинг вглубь сид-фраз эфириум кошельков запущен!'
    sendBotMsg(msg, token_bot, chat_id)
    seed_phrases = eth_parse.getseeds(wordlists)
    print(f"Начинаю просчитывать сид фразы из текстовика ожидай...")
    result_queue = eth_parse.recoveraddr(seed_phrases, num_children, threads, token_bot, chat_id)
    processed_seeds = 0  
    for _ in range(len(seed_phrases)):
        seed_phrase,debank, error = result_queue.get()
        if error:
            print(f"Error  | {error}  '")
            continue
        else:
            processed_seeds += 1
    if processed_seeds == len(seed_phrases):
        print("Скрипт закончил работу")
        msg = 'Скрипт парсинг вглубь сид-фраз эфириум кошельков закончил работу!'
        sendBotMsg(msg, token_bot, chat_id)

    time.sleep(timesl)

def start(wordlist, token_bot, chat_id, threads):
    Settings.save_empty = "n"
    msg = 'Скрипт поиска забытых биткоин кошельков запущен!'
    sendBotMsg(msg, token_bot, chat_id)
    while True:
        pool = Pool(threads)
        for _ in range(threads):
            pool.apply_async(check, (wordlist, token_bot, chat_id))
        pool.close()
        pool.join()
        time.sleep(timesl)  

def userInput():
    makeDir()
    file_name = input("\nВведи полное название файла товарищ: ")
    wordlist = getMnemonicWordsFile(file_name)
    token_bot = input("Введите токен вашего Telegram-бота: ")
    chat_id = input("Введите ваш ID в Telegram: ")
    threads = getThreadsCount()
    print("\n Скрипт поиска забытых биткоин кошельков запущен!")
    time.sleep(2)
    start(wordlist, token_bot, chat_id, threads)

def btc_seed_check_parse():
    makeDir_parse()
    file_name = input("\nВведи полное название файла товарищ: ")
    wordlists = getMnemonicWordsFiles(file_name)
    num_children = int(input("Введите сколько адрессов пропарсить вглубину сид фразы: "))
    token_bot = input("Введите токен вашего Telegram-бота: ")
    chat_id = input("Введите ваш ID в Telegram: ")
    threads = getThreadsCount()
    print("\n Скрипт парсинг вглубь сид-фраз кошельков запущен!")
    time.sleep(2)
    starts(wordlists, token_bot, chat_id, threads, num_children)

def eth_seeds():
    makeDir_eth()
    file_name = input("\nВведи полное название файла товарищ: ")
    wordlists = getMnemonicWordsFilesEth(file_name)
    token_bot = input("Введите токен вашего Telegram-бота: ")
    chat_id = input("Введите ваш ID в Telegram: ")
    threads = getThreadsCount()
    print("\n Скрипт поиска забытых эфириум кошельков запущен!")
    time.sleep(2)
    start_gen_eth(wordlists, token_bot, chat_id, threads)
    
def eth_parses():
    makeDir_eth_parse()
    file_name = input("\nВведи полное название файла товарищ: ")
    wordlists = getMnemonicWordsFilesEth_parse(file_name)
    num_children = int(input("Введите сколько адрессов пропарсить вглубину сид фразы: "))
    token_bot = input("Введите токен вашего Telegram-бота: ")
    chat_id = input("Введите ваш ID в Telegram: ")
    threads = getThreadsCount()
    print("\n Скрипт поиска забытых эфириум кошельков запущен!")
    time.sleep(2)
    start_eth_parse(wordlists, token_bot, chat_id, threads, num_children)

def main():
    parser = argparse.ArgumentParser(description='Товарищ запусти скрипт с одним из аргументов!')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('-b', action='store_true', help='Поиск забытых биткоин кошельков')
    group.add_argument('-a', action='store_true', help='Парсинг по сидке биткоин адреса в глубь кошелька')
    group.add_argument('-e', action='store_true', help='Поиск эфировских кошельков и форков')
    group.add_argument('-w', action='store_true', help='Парсинг по сидке эфира и форков в глубь кошелька')
    args = parser.parse_args()
    if args.b:
        userInput()
    elif args.a:
        btc_seed_check_parse() 
    elif args.e:
        eth_seeds()
    elif args.w:
        eth_parses()

if __name__ == '__main__':
    main()